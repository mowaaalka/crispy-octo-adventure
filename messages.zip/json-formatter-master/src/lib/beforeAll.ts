// @ts-ignore
window.__jsonFormatterStartTime = performance.now()
